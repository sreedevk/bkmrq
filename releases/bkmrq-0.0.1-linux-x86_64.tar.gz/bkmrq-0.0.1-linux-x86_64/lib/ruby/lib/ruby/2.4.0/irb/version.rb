# frozen_string_literal: false
#
#   irb/version.rb - irb version definition file
#   	$Release Version: 0.9.6$
#   	$Revision: 53141 $
#   	by Keiju ISHITSUKA(keiju@ishitsuka.com)
#
# --
#
#
#

module IRB # :nodoc:
  @RELEASE_VERSION = "0.9.6"
  @LAST_UPDATE_DATE = "09/06/30"
end
