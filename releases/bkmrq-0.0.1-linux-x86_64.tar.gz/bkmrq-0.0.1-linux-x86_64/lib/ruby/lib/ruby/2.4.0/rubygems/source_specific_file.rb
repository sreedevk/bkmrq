# frozen_string_literal: true
require 'rubygems/source/specific_file'

# TODO warn upon require, this file is deprecated.

